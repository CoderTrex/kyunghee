/*
A. ReheapDown을 nonrecursive 방식으로 작성하여라.
B. ReheapUp을 nonrecursive 방식으로 작성하여라.
C. 위 두 프로그램을 Big-O 개념으로 설명하여라.
	시간복잡도는 O(logN)으로 recursive 버전과 동일하다.
*/