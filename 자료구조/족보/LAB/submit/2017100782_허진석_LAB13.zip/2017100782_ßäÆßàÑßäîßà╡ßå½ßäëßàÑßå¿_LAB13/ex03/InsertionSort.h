#include "Student.h"

void InsertionSort(Student ary[], int numElems);