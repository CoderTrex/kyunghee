// Test driver
#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <cstring>
#include "sorted.h"

using namespace std;
void MergeList(SortedType list1, SortedType list2, SortedType &result);
void PrintList(ofstream& outFile, SortedType list);



int main()
{
  ifstream inFile;       // file containing operations
  ofstream outFile;      // file containing output
  string inFileName;     // input file external name
  string outFileName;    // output file external name
  string outputLabel;     
  string command;        // operation to be executed
  
  int number;
  ItemType item;
  SortedType list;
  bool found;
  int numCommands;

  // Prompt for file names, read file names, and prepare files
  cout << "Enter name of input command file; press return." << endl;
  cin  >> inFileName;
  inFile.open(inFileName.c_str());

  cout << "Enter name of output file; press return." << endl;
  cin  >> outFileName;
  outFile.open(outFileName.c_str());

  cout << "Enter name of test run; press return." << endl;
  cin  >> outputLabel;
  outFile << outputLabel << endl;

  inFile >> command;

  numCommands = 0;
  while (command != "Quit")
  { 
    if (command == "InsertItem")
    {
      inFile >> number; 
      item.Initialize(number);
      list.InsertItem(item);
      item.Print(outFile);
      outFile << " is inserted" << endl;
    }
    else if (command == "DeleteItem")
    {
      inFile >> number;
      item.Initialize(number);
      list.DeleteItem(item);
      item.Print(outFile);
      outFile << " is deleted" << endl;
    }
    else if (command == "RetrieveItem")
    {
      inFile >> number;
      item.Initialize(number);
      list.RetrieveItem(item, found);
      if (found)
        outFile << number << " found in list." << endl;
      else outFile << number  << " not in list."  << endl;  
    } 
    else if (command == "LengthIs")  
      outFile << "Length is " << list.LengthIs() << endl;
    else if (command == "IsFull")
      if (list.IsFull())
        outFile << "List is full." << endl;
      else outFile << "List is not full."  << endl;  
    else PrintList(outFile, list);
    numCommands++;
    cout <<  " Command number " << numCommands << " completed." 
         << endl;
    inFile >> command;
  };
 
  cout << "Testing completed."  << endl;
  inFile.close();
  outFile.close();
  return 0;
}

void MergeList(SortedType list1, SortedType list2, SortedType &result){
  ItemType item1, item2;
  result.ResetList();
  list1.ResetList();
  list2.ResetList();

  int len_1 = list1.LengthIs();
  int len_2 = list2.LengthIs();
  for (int i = 0; i < len_1; i++){
    list1.GetNextItem(item1);
    result.InsertItem(item1);
  }
  for (int i = 0; i < len_2; i++){
    list2.GetNextItem(item2);
    result.InsertItem(item2);
  }
}

void PrintList(ofstream& dataFile, SortedType list)
// Pre:  list has been initialized.      
//       dataFile is open for writing.   
// Post: Each component in list has been written to dataFile.
//       dataFile is still open.         
{
  int length;
  ItemType item;

  list.ResetList();
  length = list.LengthIs();
  for (int counter = 1; counter <= length; counter++)
  {
    list.GetNextItem(item);
    item.Print(dataFile);
  }
  dataFile << endl;
}